const student = {
    name:"Helsinki",
    age:4,
    projects:{
        dicegame:"Two player dice game using Javascript"
    }
}

const{name , age , projects:{dicegame}} = student;
console.log(name,age,dicegame);